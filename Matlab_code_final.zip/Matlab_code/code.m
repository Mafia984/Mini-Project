% This code finds the physical layer achievble data rate of 5G based on CQI-MCS mapping table
% Written by Pradip Barik, Senior research scholar, IIT Kharagpur, India

clear all;
close all;
clc;

circle(0,0,0.5);
hold on;
plot(0,0,'d','LineWidth',2);  %control station placement
hold on;
r=0.5; %radius of disk
xx0=0; yy0=0; %centre of disk
areaTotal=pi*r^2; %area of disk
NRB_tot=275;
numbPoints=50; % Number of sensor nodes in the area

% Reading the CQI-MCS table from 3GPP specification
num = xlsread('C:\Users\Admin\Downloads\Matlab_code\CQI_MCS_mm.xlsx'); % Change the path on your computer
save('savenum.mat','num');
example = matfile('savenum.mat');
CQI_MCS_NR= example.num;

% Creating the user information (Location, Data rate requirements)
a = 0.1;
b = 0.5;
radius1 = (b-a).*rand(numbPoints,1) + a;

a = 0;
b = 360;
theta1 = (b-a).*rand(numbPoints,1) + a;

for i=1:numbPoints
xx1(i)=radius1(i)*cosd(theta1(i))+xx0;
yy1(i)=radius1(i)*sind(theta1(i))+yy0;
end

%Shift centre of disk to (xx0,yy0)

scatter(xx1,yy1,'r');
labels = cellstr( num2str([1:numbPoints]') );
text(xx1,yy1,labels);
%voronoi(xx1,yy1);
xlabel('x');ylabel('y');
axis square;

user_info(1,:)=xx1;
user_info(2,:)=yy1;

% Required data rates of the users
% Calculate required data rate based on video suspecious object data

% % a=5;
% % b=10;
% % rate = (b-a).*rand(numbPoints,1) + a;

user_info(3,:)=rate;


for i=1:8
       % Find required data from the sensor nodes insiode the sector i
   
    % Findind achievable data rate using CQI MCS mapping
    rate_per_RB(i)=(CQI_MCS_NR(#rand_no+1,5)*log2(CQI_MCS_NR(#rand_no+1,4))*114)/(17.6*14);
    
    % Calculating required RBs
    req_RB(i)=ceil(#required data/rate_per_RB(i));
    
    % Repear it for anchor drone to the control station
    
        % Findind achievable data rate using CQI MCS mapping
    rate_per_RB(i)=(CQI_MCS_NR(#rand_no+1,5)*log2(CQI_MCS_NR(#rand_no+1,4))*114)/(17.6*14);
    
    % Calculating required RBs
    req_RB(i)=ceil(#required data/rate_per_RB(i));
end

req_RB_total=sum(req_RB); % Total throughput in Mbps


