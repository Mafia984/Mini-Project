% This code implements d2d communication for maximizing system throughput and supports the low data rate users
% Written by Pradip Barik, Senior research scholar, IIT Kharagpur, India
clear all;
close all;
clc;

tot_iteration=1000;
r=0.5; %radius of disk 500 meter (0.5 Km)
xx0=0; yy0=0; %centre of disk
areaTotal=pi*r^2; %area of disk
NRB_tot=275;
numbPoints_tot_all=[50:10:100];
numbPoints_active_all=[20 30 40]; % Number of users in a cell

% Reading the CQI-MCS table from 3GPP specification
num = xlsread('D:\Pen_Drive_Lockdown\Webinar_Matlab_5G\Matlab Code\CQI_MCS_mm.xlsx'); % Change the path on your computer
save('savenum.mat','num');
example = matfile('savenum.mat');
CQI_MCS_NR= example.num;

for iter3=1:length(numbPoints_active_all)
numbPoints_active=numbPoints_active_all(iter3);

for iter2=1:length(numbPoints_tot_all)
    
numbPoints_tot=numbPoints_tot_all(iter2);

for iter=1:tot_iteration

% Creating the user information (Location, Data rate requirements)
a = 10;
b = 500;
radius1 = (b-a).*rand(numbPoints_tot,1) + a;
user_info(1,:)=radius1;

a = 0;
b = 360;
theta1 = (b-a).*rand(numbPoints_tot,1) + a;
user_info(2,:)=theta1;

for i=1:numbPoints_tot
xx1(i)=radius1(i)*cosd(theta1(i))+xx0;
yy1(i)=radius1(i)*sind(theta1(i))+yy0;
end

% user_info(1,:)=xx1; % user_info contains details of the users
% user_info(2,:)=yy1;

% Required data rates of the users in Mbps
a=5;
b=10;
rate(1:numbPoints_active) = (b-a).*rand(numbPoints_active,1) + a;
rate(numbPoints_active+1:numbPoints_tot)=0;

user_info(3,:)=rate;

% Minimum data rate for guaranteeing minimum quality of service
rate_lowest=0.3685;
rate_highest=1.4432;
rate_min(1:numbPoints_active)= (rate_highest-rate_lowest).*rand(numbPoints_active,1)+ rate_lowest;
rate_min(numbPoints_active+1:numbPoints_tot)=0;
user_info(4,:)=rate_min;

user_info=user_info';

count2=1;
for i=1:numbPoints_tot
    
   % Findng CQI at the user side and sending it to BS using feedback channel
    x1=user_info(i,1)*cosd(user_info(i,2));
    y1=user_info(i,1)*sind(user_info(i,2));
    dist=sqrt(x1^2+y1^2); 
    CQI(i)=round(0.56*find_LOS_NLOS_SNR(dist)+3.8);
    if(CQI(i)~=0)
        % Findind achievable data rate using CQI MCS mapping
        rate_per_RB(i)=(CQI_MCS_NR(CQI(i)+1,5)*log2(CQI_MCS_NR(CQI(i)+1,4))*114)/(33.33*14);
    else
        rate_per_RB(i)=0;
    end
    
    if(i<=numbPoints_active && CQI(i)~=0)
        macro_non_zero_CQI(count2)=i;
        count2=count2+1;
    end
end

% Calculation of required RBs
free_rb=0;
nrb= floor(NRB_tot/numbPoints_active);  %users with CQI 0% excluse 
free_rb=NRB_tot-length(macro_non_zero_CQI)*nrb;


for i=1:numbPoints_active
    if(CQI(i)==0)
        rate_cu(i)=0;
        rate_per_RB(i)=0;
        nrb_opt(i)=0;
        continue;
    end
   
    % Calculating required RBs
    req_RB=ceil(user_info(i,3)/rate_per_RB(i));
    if(req_RB>=nrb)
        nrb_opt(i)=nrb;
    else
        nrb_opt(i)=req_RB;
        free_rb=free_rb+(nrb-req_RB);
    end

    rate_cu(i) =nrb_opt(i)*rate_per_RB(i); % Achievable rate for the users in Mbps
    
end

tot_achievable_rate_without_D2D(iter)=sum(rate_cu); % Total throughput in Mbps

%finding the unsatisfied users and the excess rate requirement
j=1;
for i=1:numbPoints_active
    if rate_cu(i)<user_info(i,3)
        CU_unsatisfied(j,1)=i;
        CU_unsatisfied(j,2)=user_info(i,3)-rate_cu(i);   %amount of excess rate required for unsatisfied users
        j=j+1;
    end;
end;

%checking if there are any unsatisfied user
if ~exist('CU_unsatisfied')
    clear user_info;  
    clear CU_unsatisfied;
          continue;
end;

%finding the D2D pairs for the unsatisfied users

%sorting the unsatisfied users in decending order of date rate requirement
[~,b] = sort(CU_unsatisfied(:,2),'descend');
CU_unsatisfied=CU_unsatisfied(b,:);

%forming clusters of users based on quadrant
cluster1=find(user_info(:,2)>=0 & user_info(:,2)<90);
cluster2=find(user_info(:,2)>=90 & user_info(:,2)<180);
cluster3=find(user_info(:,2)>=180 & user_info(:,2)<270);
cluster4=find(user_info(:,2)>=270 & user_info(:,2)<360);

%finding the location of user on the cluster and nearby suitable D2D pair
  [a,b]=size(CU_unsatisfied);
  d2d_info=zeros(a,6);
count2=0;
 for i=1:a
        if sum(ismember(cluster1,CU_unsatisfied(i)))
            location_cluster=cluster1;
        end;
        if sum(ismember(cluster2,CU_unsatisfied(i)))
            location_cluster=cluster2;
        end;
        if sum(ismember(cluster3,CU_unsatisfied(i)))
            location_cluster=cluster3;
        end;
        if sum(ismember(cluster4,CU_unsatisfied(i)))
            location_cluster=cluster4;
        end;
  %Finding the distance from the unsatisfied user to the inactive users
  count=1;
  d2d_dist=100;  %This D2D distance needs to be calculated from the interference profile after assigning the RBs
  for j=1:length(location_cluster)
      if location_cluster(j)>numbPoints_active && ~sum(ismember(d2d_info(:,1),location_cluster(j)))
          r=user_info(location_cluster(j),1);
          theta=user_info(location_cluster(j),2);   %D2D relay location
          x1=r*cosd(theta);y1=r*sind(theta);        %D2D cartesian location
          x=user_info(CU_unsatisfied(i),1)*cosd(user_info(CU_unsatisfied(i),2));
          y=user_info(CU_unsatisfied(i),1)*sind(user_info(CU_unsatisfied(i),2));
          if sqrt((x-x1)^2+(y-y1)^2)<= d2d_dist
          dis(count,1)=location_cluster(j);                        %User number which is nearby within the D2D zone
          dis(count,2)=sqrt((x-x1)^2+(y-y1)^2);  %saving the distance from the user
          dis(count,3)=CQI(location_cluster(j));
          count=count+1;
          end;
      end;
  end;
  
  %ping the users for CQI and select the best CQI user
  % If multiple users are having the same CQI then the selection is based on the lowest distance from the D2D Tx
  if exist('dis')
      % Selecting the user having CQI value higher than the CU
      dis(dis(:, 3)<= CQI(CU_unsatisfied(i)), :)= [];  
  [~,b] = sort(dis(:,3),'descend');  %sorting the users based on CQI value
  dis=dis(b,:);
  if isempty(dis)
      break;
  end;
  dis(dis(:, 3)< dis(1,3), :)= [];  %retaining the users based on highest CQI values
  [~,b] = sort(dis(:,2),'ascend');  %sorting the users based on lowest distance from the D2D Tx
  dis=dis(b,:);
  d2d_info(i,1)=dis(1,1);   %saving the selected user number i.e. D2D Tx or DRN
  d2d_info(i,2)=dis(1,2);   %Saving the distance between relay and the unsatisfied user
  d2d_info(i,3)=dis(1,3);   %Saving the CQI value
  nrb_opt(CU_unsatisfied(i))= min(nrb_opt(CU_unsatisfied(i)),ceil(user_info(CU_unsatisfied(i),3)/rate_per_RB(dis(1,1))));
  d2d_info(i,4)=nrb_opt(CU_unsatisfied(i));   %saving number of RBs used for the D2D relay
  d2d_info(i,5)=nrb_opt(CU_unsatisfied(i))*rate_per_RB(dis(1,1));   %saving the rate using D2D
  rate_cu(CU_unsatisfied(i))=d2d_info(i,5);  %updating the rate of the CU after selecting D2D relay
  d2d_info(i,6)=CU_unsatisfied(i);  %saving the D2D Rx
  end;
  clear dis;
  count2=count2+1;
end;
no_cu_unsatisfied_before(iter)=a/numbPoints_active;
no_cu_unsatisfied_after(iter)=(a-count2)/numbPoints_active;

%calculating excess RBs at the BS after consideration of D2D relay (excess_RB in LHS is the previous extra RBs)
excess_RB=NRB_tot-sum(nrb_opt);

% Checking whether there are any excess RBs and any user is not satisfied having CQI greater than zero. If yes, then distribute the RBs
%==========================================================================

while excess_RB~=0
    count=1;
for i=1:size(CU_unsatisfied)
    if (rate_cu(CU_unsatisfied(i,1)) < user_info(CU_unsatisfied(i,1),3)) && rate_cu(CU_unsatisfied(i,1))~=0
        nrb_opt(CU_unsatisfied(i,1))=nrb_opt(CU_unsatisfied(i,1))+1;
        if d2d_info(i,1)==0
            rate_cu(CU_unsatisfied(i,1))=nrb_opt(CU_unsatisfied(i,1))*rate_per_RB(CU_unsatisfied(i,1));
        else
            rate_cu(CU_unsatisfied(i,1))=nrb_opt(CU_unsatisfied(i,1))*rate_per_RB(d2d_info(i,1));
        end;
        excess_RB=excess_RB-1;
        count=0;
    end;
    if excess_RB==0
        break;
    end;
end;
    if count==1
        break;
    end;
end;
%==========================================================================

tot_achievable_rate_with_D2D(iter)=sum(rate_cu);
tput_gain(iter)=tot_achievable_rate_with_D2D(iter)-tot_achievable_rate_without_D2D(iter);
clear user_info;  
clear CU_unsatisfied;
end;
tput_gain_final(iter3,iter2)=sum(tput_gain)/tot_iteration;
no_cu_unsatisfied_before_final(iter3,iter2)=sum(no_cu_unsatisfied_before)/tot_iteration;
no_cu_unsatisfied_after_final(iter3,iter2)=sum(no_cu_unsatisfied_after)/tot_iteration;
clc;
disp('Total User Number');
disp(numbPoints_tot);
disp('Active user number');
disp(numbPoints_active);
clearvars -except xx0 yy0 tput_gain_final r areaTotal NRB_tot numbPoints_active numbPoints_active_all numbPoints_tot_all CQI_MCS_NR iter tot_iteration iter2 iter3 no_cu_unsatisfied_before_final no_cu_unsatisfied_after_final
end

end

figure(1);
for i=1:length(numbPoints_active_all)
plot(numbPoints_tot_all,tput_gain_final(i,:));
hold on;
end

figure(2);
for i=1:length(numbPoints_active_all)
plot(numbPoints_tot_all,no_cu_unsatisfied_before_final(i,:)*100);
hold on;
plot(numbPoints_tot_all,no_cu_unsatisfied_after_final(i,:)*100);
hold on;
end