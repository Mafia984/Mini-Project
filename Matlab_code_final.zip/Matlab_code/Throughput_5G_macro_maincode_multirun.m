% This code finds the physical layer achievble data rate of 5G based on CQI-MCS mapping table. It finds the system throughput using Monte-Carlo Method
% Written by Pradip Barik, Senior research scholar, IIT Kharagpur, India

clear all;
close all;
clc;

tot_iteration=100;
r=0.5; %radius of disk 500 meter (0.5 Km)
xx0=0; yy0=0; %centre of disk
areaTotal=pi*r^2; %area of disk
NRB_tot=275;
numbPoints_tot=[10:10:90]; % Number of users in a cell

%% using poisson distribution
%lambda_users=15;
%numbPoints1=poissrnd(areaTotal*lambda_users);  %Poisson  number of users 

%% Reading the CQI-MCS table from 3GPP specification
num = xlsread('D:\Pen_Drive_Lockdown\Webinar_Matlab_5G\Matlab Code\CQI_MCS_mm.xlsx'); % Change the path on your computer
save('savenum.mat','num');
example = matfile('savenum.mat');
CQI_MCS_NR= example.num;

for iter2=1:length(numbPoints_tot);
numbPoints=numbPoints_tot(iter2);

for iter=1:tot_iteration

%% Creating the user information (Location, Data rate requirements)
a = 0.1;
b = 0.5;
radius1 = (b-a).*rand(numbPoints,1) + a;

a = 0;
b = 360;
theta1 = (b-a).*rand(numbPoints,1) + a;

for i=1:numbPoints
xx1(i)=radius1(i)*cosd(theta1(i))+xx0;
yy1(i)=radius1(i)*sind(theta1(i))+yy0;
end

user_info(1,:)=xx1; % user_info contains details of the users
user_info(2,:)=yy1;

%% Required data rates of the users
a=5;
b=10;
rate = (b-a).*rand(numbPoints,1) + a;

user_info(3,:)=rate;

% Minimum data rate for guaranteeing minimum quality of service
rate_lowest=0.3685;
rate_highest=1.4432;
rate_min= (rate_highest-rate_lowest).*rand(numbPoints,1)+ rate_lowest;
user_info(4,:)=rate_min;

user_info=user_info';

count2=1;
for i=1:numbPoints
    
   % Findng CQI at the user side and sending it to BS using feedback channel
    dist=sqrt(user_info(i,1)^2+user_info(i,2)^2)*1000; % Converting into meter 
    CQI(i)=round(0.56*find_LOS_NLOS_SNR(dist)+3.8);
    
    if(CQI(i)~=0)
        macro_non_zero_CQI(count2)=i;
        count2=count2+1;
    end
end

%% Calculation of required RBs
free_rb=0;
nrb= floor(NRB_tot/(length(macro_non_zero_CQI)));  %users with CQI 0% excluse 
free_rb=NRB_tot-length(macro_non_zero_CQI)*nrb;

for i=1:length(macro_non_zero_CQI)

   
    % Findind achievable data rate using CQI MCS mapping
    rate_per_RB(i)=(CQI_MCS_NR(CQI(macro_non_zero_CQI(i))+1,5)*log2(CQI_MCS_NR(CQI(macro_non_zero_CQI(i))+1,4))*114)/(33.33*14);
    
    % Calculating required RBs
    req_RB=ceil(user_info(i,3)/rate_per_RB(i));
    if(req_RB>=nrb)
        nrb_opt(i)=nrb;
    else
        nrb_opt(i)=req_RB;
        free_rb=free_rb+(nrb-req_RB);
    end

    rate_cu(i) =nrb_opt(i)*rate_per_RB(i); % Achievable rate for the users in Mbps
    
end
free_RB_tot(iter)=free_rb;
tot_achievable_rate(iter)=sum(rate_cu); % Total throughput in Mbps
clearvars -except tot_achievable_rate r xx0 yy0 areaTotal NRB_tot numbPoints CQI_MCS_NR iter tot_iteration iter2 numbPoints_tot tot_achievable_rate_final free_RB_tot_final free_RB_tot
if(mod(iter,10)==0)
    clc;
    disp('Current iteration count:');
    disp(iter);
    disp('User Number:');
    disp(numbPoints);
end
end

tot_achievable_rate_final(iter2)=sum(tot_achievable_rate)/tot_iteration;
free_RB_tot_final(iter2)=sum(free_RB_tot)/tot_iteration;
clear tot_achievable_rate
end

figure(1);
plot(numbPoints_tot,tot_achievable_rate_final);

figure(2);
plot(numbPoints_tot,free_RB_tot_final);
