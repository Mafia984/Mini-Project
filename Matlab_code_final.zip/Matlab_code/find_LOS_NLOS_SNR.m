function [ SNR_tot ] = find_LOS_NLOS_SNR( dist )
% This function finds the channel SNR based on LOS and NLOS probability in 5G
% Defining the specifications for the channel model
% Written by Pradip Barik, Senior research scholar, IIT Kharagpur, India

d_2D=dist;
h_BS=25; h_UT=2.5; fc=2.8; c=3e8; h_E=1; % Centre frequency is expressed in GHz
d_BP=4*(h_BS-h_E)*(h_UT-h_E)*(fc/c);
K=10^(-2);
NRB_tot=273;
G_T=10; G_R=10;


    m = 1;
    v_LOS = 10^(4/10);                         %Creating log normal shadowing for LOS with unit mean and variance of 4 dB
    v_NLOS = 10^(6/10);                         %Creating log normal shadowing for LOS with unit mean and variance of 6 dB
    
    mu_LOS = log((m^2)/sqrt(v_LOS+m^2));
    sigma_LOS = sqrt(log(v_LOS/(m^2)+1));
    x_LOS=lognrnd(mu_LOS,sigma_LOS,1,1);
    
    mu_NLOS = log((m^2)/sqrt(v_NLOS+m^2));
    sigma_NLOS = sqrt(log(v_NLOS/(m^2)+1));
    x_NLOS=lognrnd(mu_NLOS,sigma_NLOS,1,1);
    
    z=exprnd(1,1);                    % Creating fast fading gain coefficients with exponential distribution(unit mean)
    
    G_LOS=10*log10(K*x_LOS*z);
    G_NLOS=10*log10(K*x_NLOS*z);
    
    d_3D=sqrt((d_2D)^2+(h_BS-h_UT)^2);
    PL_NLOS1=13.54+39.08*log10(d_3D)+20*log(fc)-0.6*(h_UT-1.5);
    if(d_2D<=d_BP)
        PL_LOS=28.0+22*log10(d_3D)+20*log10(fc);
    else
        PL_LOS=28.0+40*log10(d_3D)+20*log10(fc)-9*log10((d_BP)^2+(h_BS-h_UT)^2);
    end
    PL_NLOS=max(PL_LOS,PL_NLOS1);
    
    Tot_gain_LOS=G_LOS-PL_LOS;
    Tot_gain_NLOS=G_NLOS-PL_NLOS;
    
    %Calculating power per RB: Total Tx power of BS=46dBm and initially power is equally divided among the total RBs noise power per RB bandwidth=-148.365 dB
    SNR_LOS=((10^(16/10)/NRB_tot)*10^(Tot_gain_LOS/10)*G_T*G_R)/(10^-(14.84));      %Considering only the noise PSD -174dBm/Hz, noise power per RB=-148.365dB
    SNRdB_LOS=10.*log10(SNR_LOS);
    
    %Calculating power per RB: Total Tx power of BS=46dBm and initially power is equally divided among the total RBs noise power per RB bandwidth=-148.365 dB
    SNR_NLOS=((10^(16/10)/NRB_tot)*10^(Tot_gain_NLOS/10)*G_T*G_R)/(10^-(14.84));      %Considering only the noise PSD -174dBm/Hz, noise power per RB=-148.365dB
    SNRdB_NLOS=10.*log10(SNR_NLOS);
    
    % Now computing the overall SNR based on LOS_NLOS probability
     if(d_2D<=18)
        P_LOS=1;
        P_NLOS=0;
    else
        P_LOS=(18/d_2D)+exp(-d_2D/63)*(1-18/d_2D);
        P_NLOS=1-P_LOS;
    end    
    
    SNR_tot=SNRdB_LOS*P_LOS+SNRdB_NLOS*P_NLOS;
   
    % Thresholding depending on receiver sensitivity
    if SNR_tot>=20
        SNR_tot=20;
    end;
    if SNR_tot<-5
        SNR_tot=-(3.8/0.56);
    end;

end

